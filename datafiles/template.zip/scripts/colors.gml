// colors.gml is the script that controls your color palettes.
// RoA Color GML Helper: https://cl-9a.github.io/RoAColorsGmlHelper/