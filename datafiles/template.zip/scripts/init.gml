// NORMAL READ
char_height = 52
knockback_adj = 1
walk_speed = 3.25
walk_accel = 0.20
walk_turn_time = 6
initial_dash_time = 14
initial_dash_speed = 7
dash_speed = 6.50
dash_turn_time = 10
dash_turn_accel = 1.50
dash_stop_time = 4
dash_stop_percent = 0.35
ground_friction = 0.50
moonwalk_accel = 1.30
leave_ground_max = 6
max_jump_hsp = 6
air_max_speed = 4
jump_change = 3
air_accel = 0.30
prat_fall_accel = 0.85
air_friction = 0.04
max_fall = 10
fast_fall = 14
gravity_speed = 0.50
hitstun_grav = 0.50
jump_start_time = 5
jump_speed = 11
short_hop_speed = 6
djump_speed = 10
djump_accel = 0
djump_accel_start_time = 0
djump_accel_end_time = 0
max_djumps = 1
walljump_hsp = 7
walljump_vsp = 8
land_time = 4
prat_land_time = 10
wave_friction = 0.12
roll_forward_max = 9
roll_backward_max = 9
wave_land_time = 8
wave_land_adj = 1.30
air_dodge_speed = 7.50
techroll_speed = 10
idle_anim_speed = 0.10
crouch_anim_speed = 0.10
walk_anim_speed = 0.12
dash_anim_speed = 0.20
pratfall_anim_speed = 0.25
double_jump_time = 32
walljump_time = 32
wall_frames = 2
dodge_startup_frames = 1
dodge_active_frames = 1
dodge_recovery_frames = 4
tech_active_frames = 3
tech_recovery_frames = 1
techroll_startup_frames = 1
techroll_active_frames = 4
techroll_recovery_frames = 2
air_dodge_startup_frames = 1
air_dodge_active_frames = 4
air_dodge_recovery_frames = 2
roll_forward_startup_frames = 1
roll_forward_active_frames = 4
roll_forward_recovery_frames = 2
roll_back_startup_frames = 1
roll_back_active_frames = 4
roll_back_recovery_frames = 2
crouch_startup_frames = 2
crouch_active_frames = 8
crouch_recovery_frames = 2
bubble_x = 0
bubble_y = 8
// NORMAL READ END

// sounds are handled in the sounds code
land_sound = asset_get("sfx_land_light");
landing_lag_sound = asset_get("sfx_land_med");
waveland_sound = asset_get("sfx_waveland_ran");
jump_sound = asset_get("sfx_jumpground");
djump_sound = asset_get("sfx_jumpair");
air_dodge_sound = asset_get("sfx_quick_dodge");

set_victory_bg(sprite_get("victory_background"));
hurtbox_spr         = asset_get("ex_guy_hurt_box");
crouchbox_spr       = asset_get("ex_guy_crouch_box");
air_hurtbox_spr     = -1; // -1 = use hurtbox_spr
hitstun_hurtbox_spr = -1; // -1 = use hurtbox_spr

// Character-specific assets init

//Sprites
spr_nspecial_proj = sprite_get("nspecial_proj");
spr_example = sprite_get("example"); // sprites/example_stripX.png

// SFX
sfx_example = sound_get("example"); // sounds/example.ogg

// VFX
vfx_example = hit_fx_create(spr_example, 54);

// Variables
rainbow_color = c_white; // (used for one of Sandbert w/ a Phone's cheat codes)



// Animation Info

// Misc. animation speeds


/*

Muno's Words of Wisdom: Due to a Certified Dan Moment, you must duplicate the
last frame of your crouch animation. So like, if your animation has 10 frames
total, add an 11th that's the copy of the 10th. You do NOT include this 11th
frame in the crouch_recovery_frames or etc; configure these values AS IF there
were only 10 frames.

The reason for this is that otherwise, the crouch just glitches out at the end
of the standing-up animation. Dan Moment

*/





// Visual offsets for when you're in Ranno's bubble




// Muno template: (don't change)

user_event(14); // General init

// Extra variables made by ROA Assembler

